param([string]$Keil='D:\NewMDK5.36\UV4\UV4.exe')
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$project=Join-Path $root 'MDK-ARM\DigitalElectronicseCode.uvprojx'
$output=Join-Path $root 'Verification'
New-Item -ItemType Directory -Force -Path $output | Out-Null
$log=Join-Path $output 'keil_build.log'
$process=Start-Process -FilePath $Keil -ArgumentList @('-r',('"'+$project+'"'),'-t','DigitalElectronicseCode','-j0','-o',('"'+$log+'"')) -WindowStyle Hidden -PassThru
$process.WaitForExit()
$content=Get-Content -LiteralPath $log -Raw
Write-Output $content
if($content -notmatch '0 Error\(s\), 0 Warning\(s\)') { throw 'Keil构建未达到0错误0警告' }
$hex=Join-Path $root 'MDK-ARM\DigitalElectronicseCode\DigitalElectronicseCode.hex'
if(!(Test-Path -LiteralPath $hex)) { throw '未生成HEX' }
$map=Join-Path $root 'MDK-ARM\DigitalElectronicseCode\DigitalElectronicseCode.map'
$memory=[regex]::Match((Get-Content -LiteralPath $map -Raw),'Total RW\s+Size\s+.*?\s(\d+)\s+\(')
if(!$memory.Success) { throw '无法读取SRAM占用' }
$used=[int]$memory.Groups[1].Value
if($used -gt 18432) { throw "SRAM余量不足: $used/20480，至少需要2048字节余量" }
Write-Output "SRAM=$used/20480 free=$(20480-$used) bytes"
Get-FileHash -LiteralPath $hex -Algorithm SHA256 | Format-List
