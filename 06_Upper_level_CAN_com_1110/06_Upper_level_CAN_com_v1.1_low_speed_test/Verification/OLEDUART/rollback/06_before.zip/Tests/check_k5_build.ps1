param([Parameter(Mandatory=$true)][string]$BuildRoot)
$ErrorActionPreference='Stop'
$map=Get-Content (Join-Path $BuildRoot 'F103_K5FIX.map') -Raw
$memory=[regex]::Match($map,'Total RW\s+Size.*?\s(\d+)\s+\(')
if(!$memory.Success){throw '无法读取SRAM占用'}
$used=[int]$memory.Groups[1].Value
if($used -gt 20480){throw 'SRAM越界'}
Write-Output "SRAM=$used/20480 free=$(20480-$used) bytes"
$base=0; $end=0
foreach($line in Get-Content (Join-Path $BuildRoot 'F103_K5FIX.hex')){
    $count=[Convert]::ToInt32($line.Substring(1,2),16)
    $address=[Convert]::ToInt32($line.Substring(3,4),16)
    $type=[Convert]::ToInt32($line.Substring(7,2),16)
    if($type -eq 4){$base=[Convert]::ToInt32($line.Substring(9,4),16)*65536}
    if($type -eq 0){$end=[Math]::Max($end,$base+$address+$count)}
}
if($end -ge 0x0800F800){throw 'HEX侵入启动身份保留区'}
Write-Output ('Flash end=0x{0:X8} < 0x0800F800' -f $end)
$html=Get-Content (Join-Path $BuildRoot 'F103_K5FIX.htm') -Raw
function Depth([string]$Name){
    $section=[regex]::Match($html,'(?s)<P><STRONG><a name="\[[^]]+\]"></a>'+[regex]::Escape($Name)+'</STRONG>.*?(?=<P><STRONG>|\z)').Value
    $match=[regex]::Match($section,'Max Depth =\s*(\d+)')
    if(!$match.Success){throw "调用图缺失:$Name"}
    return [int]$match.Groups[1].Value
}
foreach($entry in @(@('ProtocolTask',1280),@('PeriodicTask',384),@('LogTask',2560),@('OledTask',768),@('HealthTask',384),@('KeyTask',384))){
    $depth=Depth $entry[0]; $margin=$entry[1]-$depth
    if($margin -lt 256){throw "静态栈余量不足:$($entry[0])"}
    Write-Output "$($entry[0]) allocated=$($entry[1]) depth=$depth margin=$margin"
}
$protocol=Depth 'ProtocolTask'
$callback=[Math]::Max((Depth 'LogEvent'),(Depth 'ProtocolSend'))
$conservative=$protocol+$callback
if($conservative -ge 1280){throw '保守间接回调预算已超过协议任务栈'}
Write-Output "Protocol conservative callback bound=$conservative/1280 margin=$(1280-$conservative); runtime high-water validation REQUIRED"
