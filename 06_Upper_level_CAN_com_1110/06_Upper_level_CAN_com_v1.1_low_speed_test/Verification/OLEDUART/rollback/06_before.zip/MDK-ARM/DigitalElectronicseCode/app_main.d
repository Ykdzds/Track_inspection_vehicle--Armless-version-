digitalelectronicsecode\app_main.o: ..\APP\app_main.c
digitalelectronicsecode\app_main.o: ..\APP\app_main.h
digitalelectronicsecode\app_main.o: ..\APP\can_upper_task.h
