#include "can_upper_task.h"
#include "can_upper_protocol.h"
#include "can_upper_boot.h"
#include "can_upper_control.h"
#include "can_upper_ui.h"
#include "can.h"
#include "usart.h"
#include "i2c.h"
#include "iwdg.h"
#include "OLED.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include <stdio.h>
#include <string.h>

#define LOG_QUEUE_LENGTH 8U
#define TASK_COUNT 6U

typedef struct
{
    uint32_t timestamp, detail;
    uint16_t id, sequence;
    uint8_t kind, success, dlc, type;
    UpperLinkState_t state;
    uint8_t data[104];
} UpperLog_t;

static UpperProtocol_t protocol;
static UpperControl_t control;
static UpperUiView_t view;
static StaticTask_t task_controls[TASK_COUNT];
static StackType_t protocol_stack[320], periodic_stack[96], log_stack[640], oled_stack[192], health_stack[96], key_stack[96];
static StaticQueue_t log_control;
static uint8_t log_storage[LOG_QUEUE_LENGTH * sizeof(UpperLog_t)];
static QueueHandle_t log_queue;
static TaskHandle_t protocol_task_handle;
static volatile uint32_t task_heartbeat[TASK_COUNT];
static volatile uint32_t log_dropped, log_event_dropped, log_frame_suppressed, log_record_suppressed, log_uart_bytes, uart_errors;
static uint8_t oled_present;
static uint32_t log_stats_at, log_started_at, log_last_error_time, log_error_suppressed;
static uint16_t log_last_error_id = 0xFFFFU;
typedef struct { uint32_t key, at; uint8_t seen; } LogErrorGate_t;
static LogErrorGate_t log_errors[16];
static uint8_t log_error_next, log_record_seen[UPPER_RECORD_COUNT];
static uint32_t log_lower_boot;
static uint16_t log_link_token, log_motion_token;
static UpperControlState_t log_control_state;
static uint8_t log_observed, log_capability_state, log_capability_attempt;
static uint32_t log_target_at;
static uint8_t log_target_seen, log_target_data[6];
static uint32_t log_record_at[UPPER_RECORD_COUNT];
static uint32_t log_gate_at[13], log_gate_seen, log_gate_mask;
static uint16_t log_gate_detail, log_gate_query_detail;
static uint8_t log_gate_query_attempt, log_gate_query_result;
static uint32_t log_recovery_at;
static uint8_t log_recovery_reason;
extern uint8_t OLED_DisplayBuf[8][128];

static uint8_t LogPriority(const UpperLog_t *message)
{
    if (message->kind == 3U || message->kind == 10U || ((message->kind == 0U || message->kind == 4U) && !message->success) ||
        (message->kind == 1U && (message->type == UPPER_EVENT_REJECT || message->type == UPPER_EVENT_TX_ERROR))) return 0U;
    if (message->kind == 1U || message->kind == 5U || message->kind == 8U) return 1U;
    if (message->kind == 6U || message->kind == 9U || message->kind == 11U || message->kind == 12U) return 2U;
    return message->kind == 2U ? 4U : 5U;
}

static void LogPush(const UpperLog_t *message)
{
    UpperLog_t queued;
    UBaseType_t count, index;
    uint8_t priority = LogPriority(message), inserted = 0U;
    taskENTER_CRITICAL();
    count = uxQueueMessagesWaiting(log_queue);
    if (count == LOG_QUEUE_LENGTH)
    {
        for (index = 0U; index < count; ++index)
        {
            xQueueReceive(log_queue, &queued, 0U);
            if (index + 1U == count && LogPriority(&queued) > priority) break;
            xQueueSend(log_queue, &queued, 0U);
        }
        ++log_dropped;
        if (index == count)
        {
            if (priority <= 2U) ++log_event_dropped;
            taskEXIT_CRITICAL();
            return;
        }
        if (LogPriority(&queued) <= 2U) ++log_event_dropped;
        --count;
    }
    for (index = 0U; index < count; ++index)
    {
        xQueueReceive(log_queue, &queued, 0U);
        if (!inserted && priority < LogPriority(&queued))
        {
            xQueueSend(log_queue, message, 0U);
            inserted = 1U;
        }
        xQueueSend(log_queue, &queued, 0U);
    }
    if (!inserted) xQueueSend(log_queue, message, 0U);
    taskEXIT_CRITICAL();
}

static uint8_t LogError(uint32_t key, uint16_t id, uint32_t now)
{
    uint8_t index;
    log_last_error_id = id;
    log_last_error_time = now;
    for (index = 0U; index < 16U; ++index)
        if (log_errors[index].seen && log_errors[index].key == key) break;
    if (index == 16U) index = log_error_next++ % 16U;
    if (log_errors[index].seen && log_errors[index].key == key &&
        (uint32_t)(now - log_errors[index].at) < UPPER_LOG_ERROR_REPEAT_MS)
    {
        ++log_error_suppressed;
        return 0U;
    }
    log_errors[index].seen = 1U;
    log_errors[index].key = key;
    log_errors[index].at = now;
    return 1U;
}

static uint8_t LogRaw(uint32_t now, uint8_t record)
{
    return (uint8_t)((UPPER_LOG_LEVEL == UPPER_LOG_LEVEL_RAW ||
        (record ? UPPER_LOG_RAW_RECORD : UPPER_LOG_RAW_FRAME)) &&
        (uint32_t)(now - log_started_at) < UPPER_LOG_RAW_DURATION_MS);
}

static void LogEvent(void *user, UpperEvent_t event, uint32_t detail)
{
    UpperLog_t message;
    const UpperRecord_t *record;
    uint32_t index;
    (void)user;
    memset(&message, 0, sizeof(message));
    message.timestamp = HAL_GetTick();
    message.kind = 1U;
    message.type = (uint8_t)event;
    message.detail = detail;
    message.id = protocol.snapshot.last_rx_id;
    message.sequence = protocol.record_header[0];
    message.state = protocol.snapshot.state;
    if ((event == UPPER_EVENT_REJECT || event == UPPER_EVENT_TX_ERROR) &&
        !LogError(0x10000000UL | ((uint32_t)event << 24) | detail,
            event == UPPER_EVENT_TX_ERROR ? (uint16_t)detail : protocol.snapshot.last_rx_id, message.timestamp)) return;
    if (event == UPPER_EVENT_RECORD)
    {
        for (index = 0U; index < UPPER_RECORD_COUNT; index++)
        {
            record = &protocol.snapshot.records[index];
            if (!record->valid || record->type != detail) continue;
            if (UPPER_LOG_LEVEL == UPPER_LOG_LEVEL_QUIET ||
                (log_record_seen[index] && (uint32_t)(message.timestamp - log_record_at[index]) < UPPER_LOG_RECORD_PERIOD_MS))
            {
                ++log_record_suppressed;
                return;
            }
            log_record_seen[index] = 1U;
            log_record_at[index] = message.timestamp;
            message.kind = 2U;
            message.type = record->type;
            message.sequence = record->sequence;
            message.dlc = (uint8_t)record->length;
            message.success = Upper_RecordFresh(&protocol.snapshot, record, message.timestamp);
            message.id = protocol.snapshot.link_token;
            memcpy(message.data, record->payload, record->length);
            break;
        }
    }
    LogPush(&message);
}

static uint8_t ProtocolSend(void *user, uint16_t id, const uint8_t data[8])
{
    (void)user;
    if (!UPPER_CAN_MOTION_ENABLED && (id == 0x080U || id == 0x110U || id == 0x111U))
        LogEvent(NULL, UPPER_EVENT_REJECT, 0x10000UL | id);
    return (uint8_t)(CanBus_Send(id, data) == HAL_OK);
}

static void LogFrame(const CanBusFrame_t *frame, uint8_t tx, uint8_t success)
{
    UpperLog_t message;
    uint32_t now = HAL_GetTick();
    uint8_t target = 0U;
    if (!success)
    {
        if (!LogError(0x20000000UL | ((uint32_t)tx << 16) | frame->id, frame->id, now)) return;
    }
    else if (tx && frame->id == 0x111U && UPPER_LOG_LEVEL != UPPER_LOG_LEVEL_QUIET)
    {
        if (log_target_seen && memcmp(log_target_data, frame->data + 2U, 6U) == 0 &&
            (uint32_t)(now - log_target_at) < UPPER_LOG_TARGET_PERIOD_MS)
        {
            ++log_frame_suppressed;
            return;
        }
        log_target_seen = 1U;
        log_target_at = now;
        memcpy(log_target_data, frame->data + 2U, 6U);
        target = 1U;
    }
    else if (!(tx && (frame->id == 0x102U || frame->id == 0x104U || frame->id == 0x105U || frame->id == 0x110U)) &&
        !(!tx && (frame->id == 0x101U || frame->id == 0x106U || frame->id == 0x120U || frame->id == 0x121U)) &&
        !(LogRaw(now, 0U) && frame->id == UPPER_LOG_RAW_ID))
    {
        ++log_frame_suppressed;
        return;
    }
    memset(&message, 0, sizeof(message));
    message.timestamp = frame->timestamp;
    message.id = frame->id;
    message.dlc = frame->dlc;
    message.kind = target ? 7U : (tx ? 4U : 0U);
    message.success = success;
    message.state = protocol.snapshot.state;
    memcpy(message.data, frame->data, 8U);
    LogPush(&message);
}

static void LogObserve(uint32_t now)
{
    static uint32_t operation_seen, operation_logged_at;
    UpperLog_t message;
    uint8_t capability = (uint8_t)(protocol.capability_active | (protocol.capability_published << 1) | (protocol.capability_confirmed << 2));
    uint8_t preparation_end = (uint8_t)(log_observed && log_control_state == SIM_AUTH_PREPARING && control.state != SIM_AUTH_PREPARING);
    uint8_t gate_index = control.detail >= 201U && control.detail <= 212U ? (uint8_t)(control.detail - 200U) : 0U;
    memset(&message, 0, sizeof(message));
    message.timestamp = now;
    message.state = protocol.snapshot.state;
    if (!log_observed || log_lower_boot != protocol.snapshot.lower_boot_id || log_link_token != protocol.snapshot.link_token)
    {
        memset(log_record_seen, 0, sizeof(log_record_seen));
        message.kind = 5U;
        message.detail = protocol.snapshot.lower_boot_id;
        message.id = protocol.snapshot.link_token;
        LogPush(&message);
    }
    if (!log_observed || log_control_state != control.state || log_motion_token != control.motion_token)
    {
        message.kind = 6U;
        message.type = (uint8_t)control.state;
        message.id = control.motion_token;
        message.detail = control.detail;
        LogPush(&message);
    }
    if (!log_observed || log_capability_state != capability || log_capability_attempt != protocol.capability_attempts)
    {
        message.kind = 8U;
        message.type = capability;
        message.sequence = protocol.capability_sequence;
        message.detail = protocol.capability_attempts;
        LogPush(&message);
    }
    if ((control.state == SIM_AUTH_PREPARING || preparation_end || (control.detail >= 201U && control.detail <= 212U)) &&
        (!log_observed || preparation_end || log_gate_detail != control.detail || log_gate_mask != control.gate.mask ||
         log_gate_query_attempt != control.query_attempts || log_gate_query_result != control.query_result || log_gate_query_detail != control.query_detail) &&
        (preparation_end || !(log_gate_seen & (1UL << gate_index)) || (uint32_t)(now - log_gate_at[gate_index]) >= UPPER_LOG_ERROR_REPEAT_MS))
    {
        message.kind = 9U; message.id = control.detail; message.sequence = control.prepare_last_reason;
        message.type = control.query_attempts; message.success = control.query_result; message.dlc = control.query_phase;
        message.detail = control.query_detail;
        memcpy(message.data, &control.gate, sizeof(control.gate));
        LogPush(&message);
        log_gate_at[gate_index] = now; log_gate_seen |= 1UL << gate_index;
        log_gate_detail = control.detail; log_gate_mask = control.gate.mask;
        log_gate_query_attempt = control.query_attempts; log_gate_query_result = control.query_result; log_gate_query_detail = control.query_detail;
    }
    if (control.operation_detail && control.operation_count != operation_seen &&
        (!operation_seen || (uint32_t)(now - operation_logged_at) >= UPPER_LOG_ERROR_REPEAT_MS))
    {
        unsigned axis;
        message.kind = 11U; message.id = control.operation_detail;
        message.detail = (uint16_t)control.rejected_rpm; message.sequence = (uint16_t)control.target_rpm;
        for (axis = 0U; axis < 2U; ++axis)
        {
            uint32_t age = now - protocol.snapshot.basic[6U + axis].timestamp;
            memcpy(message.data + axis * 4U, &age, sizeof(age));
        }
        memcpy(message.data + 8U, &protocol.snapshot.left_rpm, sizeof(int16_t));
        memcpy(message.data + 10U, &protocol.snapshot.right_rpm, sizeof(int16_t));
        LogPush(&message); operation_seen = control.operation_count; operation_logged_at = now;
    }
    if ((control.state == SIM_CROSS_SOURCE_STOP || control.state == SIM_RECOVERY_VERIFY || control.detail == 115U) &&
        (!log_recovery_at || log_recovery_reason != control.recovery_reason || (uint32_t)(now - log_recovery_at) >= UPPER_LOG_ERROR_REPEAT_MS))
    {
        const UpperRecord_t *record = UpperControl_Record(&protocol.snapshot, 0x11U);
        uint32_t flags = record ? Upper_ReadU32(record->payload + 12U) : 0U;
        uint32_t ages[2];
        ages[0] = now - protocol.snapshot.basic[6].timestamp; ages[1] = now - protocol.snapshot.basic[7].timestamp;
        message.kind = 12U; message.type = control.recovery_reason; message.detail = control.stop_event;
        message.success = control.stop_phase; message.dlc = protocol.snapshot.control_source;
        message.sequence = protocol.snapshot.lifecycle;
        memcpy(message.data, &flags, sizeof(flags)); memcpy(message.data + 4U, ages, sizeof(ages));
        LogPush(&message); log_recovery_at = now; log_recovery_reason = control.recovery_reason;
    }
    log_observed = 1U;
    log_lower_boot = protocol.snapshot.lower_boot_id;
    log_link_token = protocol.snapshot.link_token;
    log_control_state = control.state;
    log_motion_token = control.motion_token;
    log_capability_state = capability;
    log_capability_attempt = protocol.capability_attempts;
}

static void PublishUi(uint32_t now)
{
    taskENTER_CRITICAL();
    UpperUi_Publish(&control, &protocol, now, &view);
    taskEXIT_CRITICAL();
}

static void ProtocolTask(void *argument)
{
    CanBusFrame_t frame;
    CanBusTxResult_t tx_result;
    CanBusStats_t stats, previous = {0};
    UpperLog_t message;
    uint32_t now, count;
    uint8_t success;
    (void)argument;
    CanBus_SetRxTask(protocol_task_handle);
    (void)CanBus_Start();
    for (;;)
    {
        ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(10U));
        now = HAL_GetTick();
        task_heartbeat[0] = now;
        CanBus_GetStats(&stats);
        if (stats.bus_off_count != previous.bus_off_count || stats.rx_queue_overruns != previous.rx_queue_overruns ||
            stats.recovery_count != previous.recovery_count || stats.result_overruns != previous.result_overruns)
        {
            Upper_ResetSession(&protocol, now);
            CanBus_ClearPending();
            LogEvent(NULL, UPPER_EVENT_REJECT, CanBus_IsBusOff() ? 60U : 61U);
        }
        if ((stats.hal_errors != previous.hal_errors || stats.invalid_frames != previous.invalid_frames || stats.tx_errors != previous.tx_errors) &&
            LogError(0x30000000UL | stats.last_error, 0xFFFFU, now))
        {
            memset(&message, 0, sizeof(message));
            message.kind = 3U;
            message.timestamp = now;
            message.detail = stats.last_error;
            message.id = (uint16_t)stats.hal_errors;
            message.sequence = (uint16_t)stats.invalid_frames;
            message.state = protocol.snapshot.state;
            LogPush(&message);
        }
        previous = stats;
        for (count = 0U; count < 8U && CanBus_Receive(&frame); count++)
        {
            uint32_t old_boot = protocol.snapshot.lower_boot_id;
            uint16_t old_token = protocol.snapshot.link_token;
            uint32_t old_rejected = protocol.snapshot.rejected + protocol.snapshot.record_errors;
            Upper_Receive(&protocol, frame.id, frame.dlc, frame.data, frame.timestamp, now);
            LogObserve(now);
            if (frame.dlc == 8U) UpperControl_Receive(&control, &protocol, frame.id, frame.data, frame.timestamp, now);
            if (frame.id == 0x120U || frame.id == 0x121U) LogObserve(now);
            LogFrame(&frame, 0U, (uint8_t)(old_rejected == protocol.snapshot.rejected + protocol.snapshot.record_errors));
            if ((old_boot && old_boot != protocol.snapshot.lower_boot_id) || (old_token && !protocol.snapshot.link_token)) CanBus_ClearPending();
        }
        CanBus_Service(now);
        while (CanBus_GetTxResultEx(&tx_result))
        {
            frame = tx_result.frame;
            success = (uint8_t)(tx_result.outcome == UPPER_TX_OK);
            if (tx_result.outcome != UPPER_TX_CANCELLED && tx_result.outcome != UPPER_TX_REPLACED)
                Upper_TxResult(&protocol, frame.id, frame.data, success, now);
            UpperControl_TxOutcome(&control, frame.id, frame.data, tx_result.outcome, now);
            if (!success && tx_result.outcome != UPPER_TX_CANCELLED && tx_result.outcome != UPPER_TX_REPLACED)
            {
                CanBus_DropMotion();
                memset(&message, 0, sizeof(message));
                message.kind = 10U; message.id = frame.id; message.timestamp = now;
                memcpy(message.data, &tx_result, sizeof(tx_result));
                if (LogError(0x40000000UL | tx_result.outcome, frame.id, now)) LogPush(&message);
            }
            LogFrame(&frame, 1U, success);
        }
        {
            uint16_t old_token = protocol.snapshot.link_token;
            Upper_Tick(&protocol, now, (uint8_t)(CanBus_IsStarted() && !CanBus_IsBusOff()));
            if (old_token && !protocol.snapshot.link_token) CanBus_ClearPending();
        }
        {
            UpperUi_NotifyState(control.state);
            UpperUi_ConsumeEvents(&control, &protocol);
            UpperControl_Tick(&control, &protocol, now);
            if (control.state != SIM_AUTHORIZED_WAIT_ZERO && control.state != SIM_AUTHORIZED_ZERO && control.state != SIM_RUNNING) CanBus_DropMotion();
        }
        CanBus_Service(now);
        LogObserve(now);
        PublishUi(now);
    }
}

static void PeriodicTask(void *argument)
{
    TickType_t wake = xTaskGetTickCount();
    (void)argument;
    for (;;)
    {
        task_heartbeat[1] = HAL_GetTick();
        xTaskNotifyGive(protocol_task_handle);
        vTaskDelayUntil(&wake, pdMS_TO_TICKS(10U));
    }
}

static void SerialWrite(const char *text)
{
    uint16_t length = (uint16_t)strlen(text);
    if (HAL_UART_Transmit(&huart1, (uint8_t *)text, length, 100U) != HAL_OK) uart_errors++;
    else log_uart_bytes += length;
}

static void WriteHex64(const uint8_t *data, char *text)
{
    snprintf(text, 19U, "0x%08lX%08lX", (unsigned long)Upper_ReadU32(data + 4), (unsigned long)Upper_ReadU32(data));
}

static void LogRecord(const UpperLog_t *message)
{
    const uint8_t *data = message->data;
    char text[180], value1[19], value2[19];
    uint32_t offset;
    snprintf(text, sizeof(text), "[%lu] RECORD type=%02X seq=%u len=%u crc=OK token=%04X match=YES fresh=%s LINK=%s\r\n",
        (unsigned long)message->timestamp, message->type, message->sequence, message->dlc,
        message->id, message->success ? "YES" : "NO", Upper_StateName(message->state));
    SerialWrite(text);
    switch (message->type)
    {
        case 0x02:
            snprintf(text, sizeof(text), "  CAP boot=%08lX peer=%08lX caps=%08lX sources=%08lX role=%u\r\n",
                (unsigned long)Upper_ReadU32(data), (unsigned long)Upper_ReadU32(data + 4),
                (unsigned long)Upper_ReadU32(data + 8), (unsigned long)Upper_ReadU32(data + 12), data[22]);
            break;
        case 0x10:
            snprintf(text, sizeof(text), "  CONFIG rev=%lu axes=%u wheel_um=%lu/%lu counts_rev=%lu/%lu speed_limit=%u\r\n",
                (unsigned long)Upper_ReadU32(data), data[4], (unsigned long)Upper_ReadU32(data + 8),
                (unsigned long)Upper_ReadU32(data + 12), (unsigned long)Upper_ReadU32(data + 16),
                (unsigned long)Upper_ReadU32(data + 20), Upper_ReadU16(data + 34));
            break;
        case 0x11:
            snprintf(text, sizeof(text), "  CONTROL gen=%lu motion_token=%04X source=%u life=%u flags=%08lX speed_seq=%u reject=%u\r\n",
                (unsigned long)Upper_ReadU32(data), Upper_ReadU16(data + 4), data[6], data[7],
                (unsigned long)Upper_ReadU32(data + 12), Upper_ReadU16(data + 20), Upper_ReadU16(data + 26));
            break;
        case 0x12:
            snprintf(text, sizeof(text), "  HEALTH uptime=%lu reset=%08lX flags=%08lX failed_hb=%08lX valid=%04X\r\n",
                (unsigned long)Upper_ReadU32(data), (unsigned long)Upper_ReadU32(data + 4),
                (unsigned long)Upper_ReadU32(data + 8), (unsigned long)Upper_ReadU32(data + 12), Upper_ReadU16(data + 38));
            break;
        case 0x13:
            snprintf(text, sizeof(text), "  STOP gen=%lu reason=%u phase=%u zero_axes=%u failed_axes=%u time_done=%lu\r\n",
                (unsigned long)Upper_ReadU32(data), data[4], data[5], data[6], data[7], (unsigned long)Upper_ReadU32(data + 28));
            break;
        case 0x20: case 0x21:
            WriteHex64(data + 24, value1); WriteHex64(data + 40, value2);
            snprintf(text, sizeof(text), "  AXIS %u raw=%ld sample=%lu gen=%lu source_age=%lu flags=%04X net_count=%s travel_count=%s\r\n",
                data[23], (long)(int32_t)Upper_ReadU32(data), (unsigned long)Upper_ReadU32(data + 4),
                (unsigned long)Upper_ReadU32(data + 8), (unsigned long)Upper_ReadU32(data + 16), Upper_ReadU16(data + 20), value1, value2);
            break;
        case 0x22:
            WriteHex64(data + 40, value1); WriteHex64(data + 48, value2);
            snprintf(text, sizeof(text), "  WHEEL_EST flags=%08lX baseline=%lu pair_age=%u skew=%u net_mm=%s sampled_travel_mm=%s\r\n",
                (unsigned long)Upper_ReadU32(data), (unsigned long)Upper_ReadU32(data + 4), Upper_ReadU16(data + 20), Upper_ReadU16(data + 22), value1, value2);
            break;
        case 0x23:
            snprintf(text, sizeof(text), "  SYNC flags=%08lX rpm=%d/%d delta=%d comp=%d skew=%u\r\n",
                (unsigned long)Upper_ReadU32(data), (int16_t)Upper_ReadU16(data + 4), (int16_t)Upper_ReadU16(data + 6),
                (int16_t)Upper_ReadU16(data + 8), (int16_t)Upper_ReadU16(data + 12), Upper_ReadU16(data + 18));
            break;
        case 0x24:
            snprintf(text, sizeof(text), "  LOWER_CAN rx=%lu tx_done=%lu reject=%lu drop=%lu busoff=%lu record_err=%lu valid=%08lX\r\n",
                (unsigned long)Upper_ReadU32(data), (unsigned long)Upper_ReadU32(data + 4), (unsigned long)Upper_ReadU32(data + 8),
                (unsigned long)Upper_ReadU32(data + 12), (unsigned long)Upper_ReadU32(data + 20),
                (unsigned long)Upper_ReadU32(data + 24), (unsigned long)Upper_ReadU32(data + 44));
            break;
        default:
            snprintf(text, sizeof(text), "  OPTIONAL_RECORD valid transport; service fields may be UNKNOWN\r\n");
            break;
    }
    SerialWrite(text);
    if (!LogRaw(HAL_GetTick(), 1U)) return;
    for (offset = 0U; offset < message->dlc; offset += 8U)
    {
        snprintf(text, sizeof(text), "  +%03lu: %02X %02X %02X %02X %02X %02X %02X %02X\r\n", (unsigned long)offset,
            data[offset],data[offset+1],data[offset+2],data[offset+3],data[offset+4],data[offset+5],data[offset+6],data[offset+7]);
        SerialWrite(text);
        task_heartbeat[2] = HAL_GetTick();
    }
}

static void LogMessage(const UpperLog_t *entry)
{
    UpperLog_t message = *entry;
    char text[320];
    if (message.kind == 0U || message.kind == 4U)
    {
        snprintf(text, sizeof(text), "[%lu] %s ID=%03X DLC=%u %02X %02X %02X %02X %02X %02X %02X %02X LINK=%s %s\r\n",
            (unsigned long)message.timestamp, message.kind == 4U ? "TX" : "RX", message.id, message.dlc,
            message.data[0],message.data[1],message.data[2],message.data[3],message.data[4],message.data[5],message.data[6],message.data[7],
            Upper_StateName(message.state), message.kind == 4U ? (message.success ? "TX_DONE" : "TX_FAILED") : (message.success ? "OK" : "REJECT"));
        SerialWrite(text);
        if (message.kind == 0U && message.id == 0x181U && message.data[5] == 0U) SerialWrite("  BMS UNKNOWN / NOT CONNECTED; not 0V or 0%\r\n");
    }
    else if (message.kind == 2U) LogRecord(&message);
    else if (message.kind == 5U)
    {
        snprintf(text, sizeof(text), "[%lu] SESSION boot=%08lX token=%04X LINK=%s\r\n",
            (unsigned long)message.timestamp, (unsigned long)message.detail, message.id, Upper_StateName(message.state));
        SerialWrite(text);
    }
    else if (message.kind == 6U)
    {
        snprintf(text, sizeof(text), "[%lu] CONTROL state=%s motion_token=%04X detail=%lu old_target_cleared=%s\r\n",
            (unsigned long)message.timestamp, UpperControl_StateName((UpperControlState_t)message.type), message.id,
            (unsigned long)message.detail, message.type == SIM_FAULT || message.type == SIM_LINK_NOT_READY ||
                        message.type == SIM_STOPPED_RELEASED ? "YES" : "NO");
        SerialWrite(text);
    }
    else if (message.kind == 12U)
    {
        uint32_t flags, ages[2];
        memcpy(&flags, message.data, sizeof(flags)); memcpy(ages, message.data + 4U, sizeof(ages));
        snprintf(text, sizeof(text), "RECOVERY %s event=%lu phase=%u owner=%u life=%u flags=%08lX axis_age=%lu/%lu\r\n",
            UpperControl_RecoveryName(message.type), (unsigned long)message.detail, message.success, message.dlc,
            message.sequence, (unsigned long)flags, (unsigned long)ages[0], (unsigned long)ages[1]);
        SerialWrite(text);
    }
    else if (message.kind == 7U)
    {
        snprintf(text, sizeof(text), "TARGET seq=%u value=%d token=%u lease=%u TX_DONE\r\n",
            Upper_ReadU16(message.data), (int16_t)Upper_ReadU16(message.data + 2),
            Upper_ReadU16(message.data + 4), Upper_ReadU16(message.data + 6));
        SerialWrite(text);
    }
    else if (message.kind == 8U)
    {
        snprintf(text, sizeof(text), "CAPABILITY seq=%u attempts=%lu active=%u tx_complete=%u confirmed=%u\r\n",
            message.sequence, (unsigned long)message.detail, message.type & 1U, (message.type >> 1) & 1U, (message.type >> 2) & 1U);
        SerialWrite(text);
    }
    else if (message.kind == 10U)
    {
        CanBusTxResult_t result;
        memcpy(&result, message.data, sizeof(result));
        snprintf(text, sizeof(text), "TX_FINAL id=%03X seq=%u token=%u cause=%u gen=%lu age=%lu mailbox=%lu TSR=%08lX ESR=%08lX K3:CONFIRM STOP\r\n",
            result.frame.id, Upper_ReadU16(result.frame.data), Upper_ReadU16(result.frame.data + 4U), (unsigned)result.outcome,
            (unsigned long)result.generation, (unsigned long)result.age, (unsigned long)result.mailbox,
            (unsigned long)result.tsr, (unsigned long)result.esr);
        SerialWrite(text);
    }
    else if (message.kind == 11U)
    {
        snprintf(text, sizeof(text), "OP_REJECT err=%u requested=%d target=%d L=%d/%lums R=%d/%lums %s\r\n",
            message.id, (int16_t)message.detail, (int16_t)message.sequence,
            (int16_t)Upper_ReadU16(message.data + 8U), (unsigned long)Upper_ReadU32(message.data),
            (int16_t)Upper_ReadU16(message.data + 10U), (unsigned long)Upper_ReadU32(message.data + 4U),
            message.id == 103U ? "ZERO FIRST: apply 0 then wait fresh zero" : "WAIT ZERO / CHECK FEEDBACK");
        SerialWrite(text);
    }
    else if (message.kind == 9U)
    {
        UpperAuthGate_t gate;
        unsigned axis;
        memcpy(&gate, message.data, sizeof(gate));
        snprintf(text, sizeof(text), "AUTH_GATE err=%u reason=%s last=%u mask=%08lX ctrl_age=%lu hb_age=%lu owner=%u life=%u gates=%02X axes=%u cap_tx=%u cap_ack=%u query=%u/%u/%u detail=%lu\r\n",
            message.id, UpperControl_DetailName(message.id), message.sequence, (unsigned long)gate.mask,
            (unsigned long)gate.control_age, (unsigned long)gate.heartbeat_age, gate.owner, gate.life, gate.gates, gate.axes,
            gate.capability_sent, gate.capability_confirmed, message.type, message.dlc, message.success, (unsigned long)message.detail);
        SerialWrite(text);
        for (axis = 0U; axis < 2U; ++axis)
        {
            const UpperAxisGate_t *check = &gate.axis[axis];
            snprintf(text, sizeof(text), "AUTH_AXIS axis=%u age=%lu fresh=%u flags=%02X online=%u enable=%u param=%u stop=%u mode=%u rpm=%d fault=%04X\r\n",
                axis, (unsigned long)check->age, check->fresh, check->flags, check->flags & 1U,
                (check->flags >> 1) & 1U, (check->flags >> 4) & 1U, (check->flags >> 5) & 1U, check->mode, check->rpm, check->fault);
            SerialWrite(text);
        }
    }
    else
    {
        snprintf(text, sizeof(text), "[%lu] %s event=%u detail=%08lX id=%03X record=%02X LINK=%s\r\n", (unsigned long)message.timestamp,
            message.kind == 3U ? "CAN_ERROR" : "PROTOCOL", message.type, (unsigned long)message.detail,
            message.id, message.kind == 3U ? 0U : message.sequence, Upper_StateName(message.state));
        SerialWrite(text);
    }
}

static void LogTask(void *argument)
{
    UpperLog_t message;
    CanBusStats_t stats;
    char text[320];
    uint32_t boot_id = protocol.snapshot.upper_boot_id;
    (void)argument;
    snprintf(text, sizeof(text), "\r\nUPPER CAN SIM V1.1 MOTION TEST K5FIX-20261021 boot=%08lX USART1=115200 CAN=500000 PA11/PA12\r\n", (unsigned long)boot_id);
    SerialWrite(text);
    SerialWrite(boot_id ? "TB6612/PWM DISABLED; keys select pages; profile controls motion\r\n" : "BOOT PERSISTENCE ERROR: CAN protocol disabled; no fixed boot fallback\r\n");
    snprintf(text, sizeof(text), "LOG mode=%u raw_frame=%u raw_record=%u period=%u record_period=%u raw_window=%lu\r\n",
        UPPER_LOG_LEVEL, UPPER_LOG_RAW_FRAME, UPPER_LOG_RAW_RECORD, UPPER_LOG_PERIOD_MS,
        UPPER_LOG_RECORD_PERIOD_MS, (unsigned long)UPPER_LOG_RAW_DURATION_MS);
    SerialWrite(text);
    for (;;)
    {
        task_heartbeat[2] = HAL_GetTick();
        if (xQueueReceive(log_queue, &message, pdMS_TO_TICKS(50U)) == pdPASS)
        {
            LogMessage(&message);
            task_heartbeat[2] = HAL_GetTick();
        }
        if ((uint32_t)(HAL_GetTick() - log_stats_at) >= UPPER_LOG_PERIOD_MS)
        {
            log_stats_at = HAL_GetTick();
            CanBus_GetStats(&stats);
            snprintf(text, sizeof(text), "STAT rx=%lu tx_done=%lu tx_err=%lu mailbox=%lu rx_drop=%lu tx_drop=%lu busoff=%lu log_drop=%lu event_drop=%lu frame_sup=%lu record_sup=%lu uart_bytes=%lu uart_err=%lu\r\n",
                (unsigned long)stats.rx_frames,(unsigned long)stats.tx_frames,(unsigned long)stats.tx_errors,
                (unsigned long)stats.mailbox_full,(unsigned long)stats.rx_queue_overruns,(unsigned long)stats.tx_dropped,
                (unsigned long)stats.bus_off_count,(unsigned long)log_dropped,(unsigned long)log_event_dropped,
                (unsigned long)log_frame_suppressed,(unsigned long)log_record_suppressed,
                (unsigned long)log_uart_bytes,(unsigned long)uart_errors);
            SerialWrite(text);
            snprintf(text, sizeof(text), "LOG error_sup=%lu last_error_id=%03X last_error_time=%lu\r\n",
                (unsigned long)log_error_suppressed, log_last_error_id, (unsigned long)log_last_error_time);
            SerialWrite(text);
            snprintf(text, sizeof(text), "TXSTAT cancel=%lu replaced=%lu expired=%lu timeout=%lu result_drop=%lu abort_timeout=%lu recovery=%lu\r\n",
                (unsigned long)stats.tx_cancelled, (unsigned long)stats.tx_replaced, (unsigned long)stats.tx_expired,
                (unsigned long)stats.tx_timeouts, (unsigned long)stats.result_overruns, (unsigned long)stats.abort_timeouts,
                (unsigned long)stats.recovery_count);
            SerialWrite(text);
        }
    }
}


static uint8_t OledHardwareInit(void)
{
    uint8_t commands[] = {0xAE,0xD5,0x80,0xA8,0x3F,0xD3,0x00,0x40,0xA1,0xC8,0xDA,0x12,
        0x81,0xCF,0xD9,0xF1,0xDB,0x30,0xA4,0xA6,0x8D,0x14,0xAF};
    return (uint8_t)(HAL_I2C_Mem_Write(&hi2c1,0x78U,0x00U,I2C_MEMADD_SIZE_8BIT,commands,sizeof(commands),10U) == HAL_OK);
}

static uint8_t OledHardwareRefreshPage(uint8_t page)
{
    uint8_t commands[3] = {(uint8_t)(0xB0U + page), 0x10U, 0x00U};
    if (HAL_I2C_Mem_Write(&hi2c1,0x78U,0x00U,I2C_MEMADD_SIZE_8BIT,commands,3U,10U) != HAL_OK) return 0U;
    return (uint8_t)(HAL_I2C_Mem_Write(&hi2c1,0x78U,0x40U,I2C_MEMADD_SIZE_8BIT,OLED_DisplayBuf[page],128U,10U) == HAL_OK);
}

static void OledTask(void *argument)
{
    UpperUiView_t snapshot;
    CanBusStats_t stats;
    char text[40];
    uint8_t row;
    uint32_t now, retry = 0U;
    uint8_t page = 0U, rendered = 0U, failures = 0U;
    (void)argument;
    for (;;)
    {
        now = HAL_GetTick();
        task_heartbeat[3] = now;
        if (!oled_present && (int32_t)(now - retry) >= 0)
        {
            oled_present = (uint8_t)(HAL_I2C_IsDeviceReady(&hi2c1, 0x78U, 1U, 10U) == HAL_OK);
            if (oled_present) oled_present = OledHardwareInit();
            if (oled_present) { page = 0U; rendered = 0U; failures = 0U; }
            retry = now + UPPER_OLED_BACKOFF_MS;
        }
        if (oled_present)
        {
            taskENTER_CRITICAL(); snapshot = view; taskEXIT_CRITICAL();
            CanBus_GetStats(&stats);
            if (!rendered)
            {
                OLED_Clear();
                for (row = 0U; row < 8U; ++row)
                {
                    UpperUi_Format(&snapshot, row, text, sizeof(text));
                    if (snapshot.page == 5U && row == 3U) snprintf(text, sizeof(text), "RX%lu TX%lu", (unsigned long)stats.rx_frames, (unsigned long)stats.tx_frames);
                    if (snapshot.page == 5U && row == 4U) snprintf(text, sizeof(text), "DROP%lu/%lu BO%lu", (unsigned long)stats.rx_queue_overruns, (unsigned long)stats.tx_dropped, (unsigned long)stats.bus_off_count);
                    OLED_ShowString(0, row * 8U, text, OLED_6X8);
                }
                rendered = 1U;
            }
            if (OledHardwareRefreshPage(page))
            {
                failures = 0U;
                page = (uint8_t)((page + 1U) & 7U);
                if (page == 0U) rendered = 0U;
            }
            else if (++failures >= UPPER_OLED_FAILURE_LIMIT)
            {
                oled_present = 0U; rendered = 0U; failures = 0U; retry = now + UPPER_OLED_BACKOFF_MS;
            }
        }
        task_heartbeat[3] = HAL_GetTick();
        vTaskDelay(pdMS_TO_TICKS(UPPER_OLED_PAGE_PERIOD_MS));
    }
}

static void KeyTask(void *argument)
{
    uint32_t now;
    uint8_t pressed;
    (void)argument;
    for (;;)
    {
        now = HAL_GetTick();
        task_heartbeat[5] = now;
        pressed = (uint8_t)((HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin) == GPIO_PIN_RESET ? 1U : 0U) |
            (HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin) == GPIO_PIN_RESET ? 2U : 0U) |
            (HAL_GPIO_ReadPin(KEY3_GPIO_Port, KEY3_Pin) == GPIO_PIN_RESET ? 4U : 0U));
        UpperUi_ScanKeysOnly(now, pressed);
        vTaskDelay(pdMS_TO_TICKS(10U));
    }
}

static void HealthTask(void *argument)
{
    uint32_t now, index;
    uint8_t healthy;
    (void)argument;
    for (;;)
    {
        now = HAL_GetTick();
        task_heartbeat[4] = now;
        healthy = 1U;
        for (index = 0U; index < 4U; index++) if ((uint32_t)(now - task_heartbeat[index]) >= 1000U) healthy = 0U;
        if ((uint32_t)(now - task_heartbeat[5]) >= 1000U) healthy = 0U;
        if (healthy) HAL_IWDG_Refresh(&hiwdg);
        vTaskDelay(pdMS_TO_TICKS(100U));
    }
}

void UpperApp_Init(void)
{
    uint32_t boot_id = UpperBoot_Allocate();
    log_started_at = HAL_GetTick();
    log_queue = xQueueCreateStatic(LOG_QUEUE_LENGTH, sizeof(UpperLog_t), log_storage, &log_control);
    Upper_Init(&protocol, boot_id, ProtocolSend, LogEvent, NULL);
    UpperControl_Init(&control, ProtocolSend, NULL);
    UpperUi_Init();
    PublishUi(HAL_GetTick());
}

void UpperApp_Start(void)
{
    uint32_t index, now = HAL_GetTick();
    for (index = 0U; index < TASK_COUNT; index++) task_heartbeat[index] = now;
    protocol_task_handle = xTaskCreateStatic(ProtocolTask, "can_protocol", 320U, NULL, 4U, protocol_stack, &task_controls[0]);
    if (protocol_task_handle == NULL ||
        xTaskCreateStatic(PeriodicTask,"can_periodic",96U,NULL,3U,periodic_stack,&task_controls[1]) == NULL ||
        xTaskCreateStatic(LogTask,"uart_log",640U,NULL,1U,log_stack,&task_controls[2]) == NULL ||
        xTaskCreateStatic(OledTask,"can_oled",192U,NULL,1U,oled_stack,&task_controls[3]) == NULL ||
        xTaskCreateStatic(HealthTask,"health",96U,NULL,5U,health_stack,&task_controls[4]) == NULL ||
        xTaskCreateStatic(KeyTask,"key_scan",96U,NULL,2U,key_stack,&task_controls[5]) == NULL) Error_Handler();
}
