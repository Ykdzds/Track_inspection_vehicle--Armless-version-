#include "can_upper_ui.h"
#include <stdio.h>
#include <string.h>
static uint8_t page, selected, raw_mask, stable_mask, long_mask;
static UpperControlState_t previous_state;
static uint32_t changed_at[3], pressed_at[3];
static const int16_t presets[] = {0,100,200,300,400,0,-100,-200,-300,-400};
static UpperUiEvent_t events[8];
static volatile uint8_t event_head, event_tail;
static volatile uint32_t quick_written, quick_read, normal_written, normal_read;
static uint32_t quick_at, normal_at;
static void PushEvent(UpperUiEventType_t type, int16_t rpm, uint32_t now)
{
    uint8_t next = (uint8_t)((event_head + 1U) & 7U);
    if (type == UPPER_UI_EVENT_QUICK_STOP) { quick_at = now; ++quick_written; return; }
    if (type == UPPER_UI_EVENT_STOP) { normal_at = now; ++normal_written; return; }
    if (next == event_tail) return;
    events[event_head].type = type; events[event_head].rpm = rpm; events[event_head].at = now; event_head = next;
}
void UpperUi_Init(void)
{
    page = selected = raw_mask = stable_mask = long_mask = 0U;
    previous_state = SIM_LINK_NOT_READY;
    memset(changed_at, 0, sizeof(changed_at)); memset(pressed_at, 0, sizeof(pressed_at));
    event_head = event_tail = 0U;
    quick_written = quick_read = normal_written = normal_read = 0U;
}
void UpperUi_NotifyState(UpperControlState_t state)
{
    if (state != previous_state)
    {
        if (state == SIM_LINK_NOT_READY || state == SIM_STOPPED_RELEASED || state == SIM_FAULT ||
            state == SIM_AUTH_PREPARING || state == SIM_STOP_REQUESTED || state == SIM_STOPPING || state == SIM_CROSS_SOURCE_STOP) selected = 0U;
        previous_state = state;
    }
}
void UpperUi_ScanKeysOnly(uint32_t now, uint8_t pressed_mask)
{
    unsigned key;
    for (key = 0U; key < 3U; ++key)
    {
        uint8_t bit = (uint8_t)(1U << key);
        if ((raw_mask & bit) != (pressed_mask & bit))
        { raw_mask ^= bit; changed_at[key] = now; }
        if ((uint32_t)(now - changed_at[key]) >= UPPER_KEY_DEBOUNCE_MS && ((stable_mask ^ raw_mask) & bit))
        {
            stable_mask ^= bit;
            if (stable_mask & bit)
            {
                pressed_at[key] = now; long_mask &= (uint8_t)~bit;
                if (key == 2U) { PushEvent(UPPER_UI_EVENT_QUICK_STOP, 0, now); selected = 0U; }
            }
            else if (!(long_mask & bit))
            {
                if (key == 0U) { page = (uint8_t)((page + 1U) % 6U); if (page == 2U) selected = 0U; PushEvent(UPPER_UI_EVENT_PAGE, 0, now); }
                else if (key == 1U && page == 2U) { selected = (uint8_t)((selected + 1U) % (sizeof(presets) / sizeof(presets[0]))); PushEvent(UPPER_UI_EVENT_APPLY, presets[selected], now); }
            }
        }
        if ((stable_mask & bit) && !(long_mask & bit) && (uint32_t)(now - pressed_at[key]) >= UPPER_KEY_LONG_MS)
        {
            long_mask |= bit;
            if (key == 0U && page == 2U)
            {
                PushEvent(UPPER_UI_EVENT_K1_LONG, 0, now);
                selected = 0U;
            }
            else if (key == 1U && page == 2U)
            { PushEvent(UPPER_UI_EVENT_STOP, 0, now); selected = 0U; }
        }
    }
}
uint8_t UpperUi_GetEvent(UpperUiEvent_t *event)
{
    if (quick_written != quick_read)
    {
        quick_read = quick_written; normal_read = normal_written; event_tail = event_head;
        event->type = UPPER_UI_EVENT_QUICK_STOP; event->rpm = 0; event->at = quick_at; return 1U;
    }
    if (normal_written != normal_read)
    {
        normal_read = normal_written; event_tail = event_head;
        event->type = UPPER_UI_EVENT_STOP; event->rpm = 0; event->at = normal_at; return 1U;
    }
    if (event_head == event_tail) return 0U;
    *event = events[event_tail]; event_tail = (uint8_t)((event_tail + 1U) & 7U); return 1U;
}
void UpperUi_ScanKeys(uint32_t now, uint8_t pressed_mask, UpperControl_t *control, UpperProtocol_t *protocol)
{
    UpperUi_NotifyState(control->state);
    UpperUi_ScanKeysOnly(now, pressed_mask);
    UpperUi_ConsumeEvents(control, protocol);
}
void UpperUi_ConsumeEvents(UpperControl_t *control, UpperProtocol_t *protocol)
{
    UpperUiEvent_t event;
    uint8_t stopped = 0U;
    while (UpperUi_GetEvent(&event))
    {
        if (event.type == UPPER_UI_EVENT_QUICK_STOP)
        { UpperControl_Intent(control, protocol, UPPER_INTENT_QUICK_STOP, 0, event.at); stopped = 1U; }
        else if (event.type == UPPER_UI_EVENT_STOP)
        { UpperControl_Intent(control, protocol, UPPER_INTENT_STOP, 0, event.at); stopped = 1U; }
        else if (stopped) continue;
        else if (event.type == UPPER_UI_EVENT_K1_LONG)
        {
            if (control->state == SIM_IDLE || control->state == SIM_STOPPED_RELEASED || control->state == SIM_CROSS_SOURCE_STOP ||
                (control->state == SIM_FAULT && control->detail == 115U)) UpperControl_Intent(control, protocol, UPPER_INTENT_AUTHORIZE, 0, event.at);
            else UpperControl_Intent(control, protocol, UPPER_INTENT_RELEASE, 0, event.at);
        }
        else if (event.type == UPPER_UI_EVENT_APPLY) UpperControl_Intent(control, protocol, UPPER_INTENT_APPLY, event.rpm, event.at);
    }
}
void UpperUi_Publish(const UpperControl_t *control, const UpperProtocol_t *protocol, uint32_t now, UpperUiView_t *view)
{
    const UpperSnapshot_t *snapshot = &protocol->snapshot;
    const UpperRecord_t *record = UpperControl_Record(snapshot, 0x11U);
    const UpperRecord_t *stop = UpperControl_Record(snapshot, 0x13U);
    memset(view, 0, sizeof(*view));
    view->page = page; view->selected_rpm = presets[selected]; view->link = snapshot->state;
    view->quick_stop = control->quick_stop;
    view->recovery_reason = control->recovery_reason;
    view->boot = snapshot->lower_boot_id; view->link_token = snapshot->link_token;
    view->owner = snapshot->control_source; view->life = snapshot->lifecycle;
    view->axes = snapshot->axes; view->gates = snapshot->gates;
    view->hb_age = snapshot->heartbeat_seen ? now - snapshot->heartbeat_at : 0xFFFFFFFFUL;
    view->last_id = snapshot->last_rx_id; view->last_rx_age = now - snapshot->last_rx_at;
    view->errors = snapshot->rejected; view->records = snapshot->record_errors;
    view->actual = Upper_BasicFresh(snapshot, 0U, now) ? snapshot->actual_mm_s : (int16_t)-32768;
    view->left = Upper_BasicFresh(snapshot, 6U, now) ? snapshot->left_rpm : (int16_t)-32768;
    view->right = Upper_BasicFresh(snapshot, 7U, now) ? snapshot->right_rpm : (int16_t)-32768;
    view->left_fault = Upper_BasicFresh(snapshot, 6U, now) ? snapshot->left_fault : 65535U;
    view->right_fault = Upper_BasicFresh(snapshot, 7U, now) ? snapshot->right_fault : 65535U;
    view->state = control->state; view->target_rpm = control->target_rpm; view->target_mm_s = control->target_mm_s;
    view->operation_detail = control->operation_detail;
    view->tx_failure = control->tx_failure; view->recovery_required = control->recovery_required;
    view->feedback_valid = (uint8_t)(snapshot->axes != 0U && snapshot->axes <= 3U);
    {
        unsigned axis;
        for (axis = 0U; axis < 2U; ++axis)
        {
            const uint8_t *data = snapshot->basic[6U + axis].data;
            if ((snapshot->axes & (1U << axis)) && (!Upper_BasicFresh(snapshot, (uint8_t)(6U + axis), now) ||
                (data[0] & 31U) != 31U || (data[0] & 32U) || data[1] != 2U || Upper_ReadU16(data + 4U)))
                view->feedback_valid = 0U;
        }
    }
    view->detail = control->detail; view->sequence = control->speed_sequence;
    view->last_reason = control->prepare_last_reason;
    if (record != 0 && Upper_RecordFresh(snapshot, record, now))
    {
        view->fresh = 1U; view->motion_token = Upper_ReadU16(record->payload + 4U);
        view->flags = Upper_ReadU32(record->payload + 12U); view->authorized = (uint8_t)((view->flags & 8U) != 0U);
        view->stop_phase = record->payload[34]; view->stop_result = record->payload[35];
        view->lease = (uint16_t)(Upper_ReadU32(record->payload + 16U) < 65535U ? Upper_ReadU32(record->payload + 16U) : 65535U);
    }
    else { view->stop_phase = view->stop_result = 255U; }
    if (stop != 0 && Upper_RecordFresh(snapshot, stop, now))
    {
        view->stop_event = Upper_ReadU32(stop->payload); view->reason = stop->payload[4];
        view->zero_mask = stop->payload[6];
    }
    if (Upper_BasicFresh(snapshot, 6U, now) && (snapshot->basic[6].data[0] & 10U) == 10U) view->enable_mask |= 1U;
    if (Upper_BasicFresh(snapshot, 7U, now) && (snapshot->basic[7].data[0] & 10U) == 10U) view->enable_mask |= 2U;
}
static const char *Owner(uint8_t owner)
{
    static const char *names[] = {"NONE","REMOTE","CLI","HMI","CAN","SAFETY"};
    return owner <= 5U ? names[owner] : "UNKNOWN";
}
static void Number(int16_t value, char *text, unsigned capacity)
{
    if (value == (int16_t)-32768) snprintf(text, capacity, "--");
    else snprintf(text, capacity, "%d", value);
}
void UpperUi_Format(const UpperUiView_t *view, uint8_t line, char *text, uint32_t capacity)
{
    char left[8], right[8];
    Number(view->left, left, sizeof(left)); Number(view->right, right, sizeof(right));
    text[0] = 0;
    if (line == 0U) { snprintf(text, capacity, "%s P%u/6", UPPER_CAN_MOTION_ENABLED ? "CAN LOW SPEED" : "CAN READONLY", view->page + 1U); return; }
    if (line == 7U) { snprintf(text, capacity, "K1:NEXT K3:QUICK"); return; }
    switch (view->page)
    {
        case 0U:
            if (line == 1U) snprintf(text, capacity, "CAN500K %s", Upper_StateName(view->link));
            if (line == 2U) snprintf(text, capacity, "BOOT:%08lX", (unsigned long)view->boot);
            if (line == 3U) snprintf(text, capacity, "LINK:%04X HB:%lu", view->link_token, (unsigned long)view->hb_age);
            if (line == 4U) snprintf(text, capacity, "OWNER:%s", Owner(view->owner));
            if (line == 5U) snprintf(text, capacity, "ID:%03X AGE:%lu", view->last_id, (unsigned long)view->last_rx_age);
            if (line == 6U) snprintf(text, capacity, "ERR:%lu REC:%lu", (unsigned long)view->errors, (unsigned long)view->records);
            break;
        case 1U:
            if (line == 1U) snprintf(text, capacity, "OWNER:%s LIFE:%u", Owner(view->owner), view->life);
            if (line == 2U) snprintf(text, capacity, "AUTH:%s %s", view->fresh ? (view->authorized ? "CAN-YES" : "CAN-NO") : "UNKNOWN", view->fresh ? "LIVE" : "STALE");
            if (line == 3U) snprintf(text, capacity, "MOTION:%04X", view->motion_token);
            if (line == 4U) snprintf(text, capacity, "AXIS:%u GATE:%02X", view->axes, view->gates);
            if (line == 5U) snprintf(text, capacity, "FLAGS:%08lX", (unsigned long)view->flags);
            if (line == 6U) snprintf(text, capacity, "LEASE:%u", view->lease);
            break;
        case 2U:
            if (line == 1U) snprintf(text, capacity, "%s", UpperControl_StateName(view->state));
            if (line == 2U) snprintf(text, capacity, "SELECT:%+d rpm", view->selected_rpm);
            if (line == 3U) snprintf(text, capacity, "TARGET:%+d rpm", view->target_rpm);
            if (line == 4U) snprintf(text, capacity, "WIRE:%+d mm/s", view->target_mm_s);
            if (line == 5U) snprintf(text, capacity, "SEQ:%u ERR:%u", view->sequence, view->detail);
            if (line == 6U)
            {
                if (view->state == SIM_STOPPED_RELEASED) snprintf(text, capacity, "STOPPED / K1 AUTH");
                else if (view->state == SIM_CROSS_SOURCE_STOP || view->state == SIM_RECOVERY_VERIFY || view->detail == 115U)
                    snprintf(text, capacity, "%s", UpperControl_RecoveryName(view->recovery_reason));
                else if (view->state == SIM_FAULT && view->recovery_required)
                    snprintf(text, capacity, view->detail == 110U ? "TX FAIL:%u K3 STOP" : "FAULT:%u K3 STOP",
                        view->detail == 110U ? view->tx_failure : view->detail);
                else if (view->operation_detail == 103U) snprintf(text, capacity, "ZERO FIRST:APPLY 0");
                else if (view->operation_detail == 104U)
                    snprintf(text, capacity, "%s", view->feedback_valid ? "WAIT ZERO" : "FB INVALID");
                else if (view->detail >= 201U && view->detail <= 212U)
                    snprintf(text, capacity, "%s/%u", UpperControl_DetailName(view->detail == 212U ? view->last_reason : view->detail), view->detail);
                else if (view->state == SIM_STOPPING || view->state == SIM_STOP_REQUESTED)
                    snprintf(text, capacity, "%s", view->quick_stop ? "QUICK STOP 0.50" : "NORMAL STOP 0.40");
                else snprintf(text, capacity, "K2:TAP RUN/HOLD STOP");
            }
            break;
        case 3U:
            if (line == 1U) snprintf(text, capacity, "L:%s R:%s rpm", left, right);
            if (line == 2U) { Number(view->actual, left, sizeof(left)); snprintf(text, capacity, "ACTUAL:%s mm/s", left); }
            if (line == 3U) snprintf(text, capacity, "L-FAULT:%04X", view->left_fault);
            if (line == 4U) snprintf(text, capacity, "R-FAULT:%04X", view->right_fault);
            if (line == 5U) snprintf(text, capacity, "ENABLE:%u AX:%u", view->enable_mask, view->axes);
            if (line == 6U) snprintf(text, capacity, "FFFF/-- = UNKNOWN");
            break;
        case 4U:
            if (line == 1U) snprintf(text, capacity, "STOP PH:%u RES:%u", view->stop_phase, view->stop_result);
            if (line == 2U) snprintf(text, capacity, "EVENT:%lu", (unsigned long)view->stop_event);
            if (line == 3U) snprintf(text, capacity, "REASON:%u", view->reason);
            if (line == 4U) snprintf(text, capacity, "ZERO:%u EN-FB:%u", view->zero_mask, view->enable_mask);
            if (line == 5U) snprintf(text, capacity, "%s", UpperControl_StateName(view->state));
            if (line == 6U) snprintf(text, capacity, "DETAIL:%u", view->detail);
            break;
        default:
            if (line == 1U) snprintf(text, capacity, "PARSE:%lu", (unsigned long)view->errors);
            if (line == 2U) snprintf(text, capacity, "RECORD:%lu", (unsigned long)view->records);
            if (line == 3U) snprintf(text, capacity, "LAST:%03X", view->last_id);
            if (line == 4U) snprintf(text, capacity, "AGE:%lu", (unsigned long)view->last_rx_age);
            if (line == 5U) snprintf(text, capacity, "CONTROL ERR:%u", view->detail);
            if (line == 6U) snprintf(text, capacity, "UART:FULL DETAILS");
            break;
    }
}
