#ifndef CAN_UPPER_TASK_H
#define CAN_UPPER_TASK_H
void UpperApp_Init(void);
void UpperApp_Start(void);
#endif
